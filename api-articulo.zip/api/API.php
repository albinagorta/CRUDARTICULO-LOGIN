<?php
    require "conexion.php";
    
    if($_SERVER['REQUEST_METHOD'] == 'GET') {
      // READ
      if(isset($_GET['codigo'])) {
        // http://localhost/PruebasCanal/API_REST.php
        $codigo = $_GET['codigo'];

        $sql_select_id = "SELECT codigo, nombre, descripcion,marca,precio FROM articulos WHERE codigo='$codigo'";
        $query_select_id = $mysqli->query($sql_select_id);
        
        $filas = $query_select_id->num_rows;
        if($filas == 0) {
          //echo "No existe ese registro";
          header("HTTP/1.0 204");
        } else {
          $resultado = $query_select_id->fetch_assoc();
          echo json_encode($resultado);
        }
      } else {
        
        $sql_select = "SELECT codigo, nombre, descripcion,marca,precio FROM articulos";
        $query_select = $mysqli->query($sql_select);

        $datos = array();
        while($resultado = $query_select->fetch_assoc()) {
          $datos[] = $resultado;
        }

        echo json_encode($datos);
      }
    } else if($_SERVER['REQUEST_METHOD'] == 'POST') {
      // CREAD
      $datos = json_decode(file_get_contents("php://input"));
      $nombre = $datos->nombre;
      $descripcion = $datos->descripcion;
      $marca = $datos->marca;
      $precio = $datos->precio;
      if(empty($nombre) || empty($descripcion) || empty($marca) || empty($precio)) {
        //echo "Faltan campos";
        header("HTTP/1.0 400");
      } else {
        $sql_insert = "INSERT INTO articulos(nombre, descripcion,marca,precio) VALUES('$nombre', '$descripcion', '$marca', '$precio')";

        $query_insert = $mysqli->query($sql_insert);

        echo "Se inserto correctamente";
      }
    } else if($_SERVER['REQUEST_METHOD'] == 'PUT') {
      // UPDATE
      $datos = json_decode(file_get_contents("php://input"));
      $codigo = $datos->codigo;
      $nombre = $datos->nombre;
      $descripcion = $datos->descripcion;
      $marca = $datos->marca;
      $precio = $datos->precio;
      
      if(empty($codigo) || empty($nombre) || empty($descripcion) || empty($marca) || empty($precio)) {
        //echo "Faltan campos";
        header("HTTP/1.0 400");
      } else {
        $sql_update = "UPDATE articulos SET nombre='$nombre', descripcion='$descripcion' , marca='$marca' , precio='$precio' WHERE codigo='$codigo'";
        $query_update = $mysqli->query($sql_update);

        echo "Se actualizo correctamente";
      }
      
    } else if($_SERVER['REQUEST_METHOD'] == 'DELETE') {
      // DELETE
      if(isset($_GET['codigo'])) {
        $codigo = $_GET['codigo'];

        $sql_delete = "DELETE FROM articulos WHERE codigo='$codigo'";
        $query_delete = $mysqli->query($sql_delete);

        echo "Se elimino el registro";
      } else {
        //echo "No hay elemento a borrar";
        header("HTTP/1.0 204");

      }
    }

?>