package com.app.session12_pract.util;

public class ConstantesBD {
    public  static  final  String NOMBREBD="BDUsuario.db",
            NOMBRETABLA="TUsuario";
    public  static  final  int VERSION=1;
}