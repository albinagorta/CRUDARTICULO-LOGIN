package com.app.session12_pract;

import androidx.recyclerview.widget.RecyclerView;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class AdaptadorArticulos extends RecyclerView.Adapter<AdaptadorArticulos.ArticuloViewHolder> {
    Context context;
    List<Articulo> listaArticulos;

    public AdaptadorArticulos(Context context, List<Articulo> listaArticulos)
    {
        this.context = context;
        this.listaArticulos = listaArticulos;
    }

    @NonNull
    @Override
    public ArticuloViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View vista = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_articulo, null, false);
        return new AdaptadorArticulos.ArticuloViewHolder(vista);
    }

    @Override
    public void onBindViewHolder(@NonNull ArticuloViewHolder holder, int position) {
        holder.tvCodigo.setText(listaArticulos.get(position).getCodigo());
        holder.tvNombre.setText(listaArticulos.get(position).getNombre());
        holder.tvDescripcion.setText(listaArticulos.get(position).getDescripcion());
        holder.tvMarca.setText(listaArticulos.get(position).getMarca());
        holder.tvPrecio.setText(listaArticulos.get(position).getPrecio());
    }

    @Override
    public int getItemCount() {
        return listaArticulos.size();
    }

    public class ArticuloViewHolder extends RecyclerView.ViewHolder {

        TextView tvCodigo, tvNombre, tvDescripcion, tvMarca, tvPrecio;

        public ArticuloViewHolder(@NonNull View itemView) {
            super(itemView);

            tvCodigo = itemView.findViewById(R.id.tvCod);
            tvNombre = itemView.findViewById(R.id.tvNom);
            tvDescripcion = itemView.findViewById(R.id.tvDes);
            tvMarca = itemView.findViewById(R.id.tvMar);
            tvPrecio = itemView.findViewById(R.id.tvPre);
        }
    }
}
